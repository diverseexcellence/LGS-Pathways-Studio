gsutil -m cp -r gs://lgs-pathways-studio/2026-04-09T17:39:39_64392
gsutil -m cp -r gs://lgs-pathways-studio/2026-04-09T17:39:39_64392 .
gcloud auth login
4/0Aci98E8d_yrU4KzfDfJjYNKn4KoNWLb6fBqMqVpgsY8l59OvCpU3iG6l7qlCX-mTyrDh0Q
gcloud auth login --no-launch-browser
gcloud storage cp -r gs://lgs-pathways-studio/2026-04-09T17:39:39_64392 .
zip -r firestore_backup.zip 2026-04-09T17:39:39_64392
